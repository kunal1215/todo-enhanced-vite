import Home from "./pages/Home";
import { TaskProvider } from "./context/TaskContext";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <TaskProvider>
        <Home />
      </TaskProvider>
    </div>
  );
}
