import PriorityBadge from "./PriorityBadge";

export default function TaskCard({ task, onToggle, onDelete, onEdit }) {
  return (
    <div className="rounded-2xl border p-4 shadow-sm bg-white flex items-start gap-3">
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => onToggle(task.id)}
        className="mt-1 h-5 w-5"
        aria-label="Toggle Complete"
      />
      <div className="flex-1">
        <div className="flex items-center justify-between gap-3">
          <h3 className={\`text-base font-semibold \${task.completed ? "line-through text-slate-400" : "text-slate-800"}\`}>
            {task.title}
          </h3>
          <PriorityBadge level={task.priority} />
        </div>
        {task.description && (
          <p className="mt-1 text-sm text-slate-600">{task.description}</p>
        )}
        <div className="mt-2 text-xs text-slate-500 flex gap-4">
          {task.dueDate && <span>Due: {task.dueDate}</span>}
          <span>Created: {new Date(task.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={() => onEdit(task)} className="rounded-xl border px-3 py-1 text-sm hover:bg-slate-50">Edit</button>
        <button onClick={() => onDelete(task.id)} className="rounded-xl border px-3 py-1 text-sm text-red-600 hover:bg-red-50">Delete</button>
      </div>
    </div>
  );
}
