import { useEffect, useState } from "react";
import { useTasks } from "../context/TaskContext";

export default function FilterBar() {
  const { state, dispatch } = useTasks();
  const { filters } = state;
  const [localQuery, setLocalQuery] = useState(filters.query);

  useEffect(() => {
    const id = setTimeout(() => {
      dispatch({ type: "SET_FILTERS", payload: { query: localQuery } });
    }, 250);
    return () => clearTimeout(id);
  }, [localQuery]);

  function togglePriority(p) {
    const next = new Set(filters.priorities);
    if (next.has(p)) next.delete(p);
    else next.add(p);
    dispatch({ type: "SET_FILTERS", payload: { priorities: next } });
  }

  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div className="flex flex-wrap gap-3">
        <div className="flex flex-col">
          <label className="text-xs text-slate-500">Date Preset</label>
          <select className="rounded-xl border px-3 py-2" value={filters.datePreset}
            onChange={(e) => dispatch({ type: "SET_FILTERS", payload: { datePreset: e.target.value } })}>
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="thisWeek">This Week</option>
            <option value="custom">Custom Range</option>
          </select>
        </div>
        {filters.datePreset === "custom" && (
          <>
            <div className="flex flex-col">
              <label className="text-xs text-slate-500">Start</label>
              <input type="date" className="rounded-xl border px-3 py-2" value={filters.startDate}
                onChange={(e) => dispatch({ type: "SET_FILTERS", payload: { startDate: e.target.value } })}/>
            </div>
            <div className="flex flex-col">
              <label className="text-xs text-slate-500">End</label>
              <input type="date" className="rounded-xl border px-3 py-2" value={filters.endDate}
                onChange={(e) => dispatch({ type: "SET_FILTERS", payload: { endDate: e.target.value } })}/>
            </div>
          </>
        )}
      </div>
      <div className="flex flex-wrap items-end gap-3">
        <fieldset className="flex items-center gap-2 border rounded-xl px-3 py-2">
          <legend className="text-xs text-slate-500">Priority</legend>
          {(["high", "medium", "low"]).map(p => (
            <label key={p} className="flex items-center gap-1 text-sm">
              <input type="checkbox" checked={filters.priorities.has(p)} onChange={() => togglePriority(p)} />
              <span className="capitalize">{p}</span>
            </label>
          ))}
        </fieldset>
        <div className="flex flex-col">
          <label className="text-xs text-slate-500">Search</label>
          <input className="rounded-xl border px-3 py-2" placeholder="Search title/description…" value={localQuery} onChange={(e) => setLocalQuery(e.target.value)} />
        </div>
      </div>
    </div>
  );
}
