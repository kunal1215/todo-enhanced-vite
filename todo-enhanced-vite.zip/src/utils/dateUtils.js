export function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value === "number") return new Date(value);
  if (typeof value === "string") {
    const [y, m, d] = value.split("-").map(Number);
    return new Date(y, m - 1, d);
  }
  return null;
}

export function isToday(date) {
  if (!date) return false;
  const d = toDate(date);
  const now = new Date();
  return d?.toDateString() === now.toDateString();
}

export function startOfWeek(date = new Date()) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function endOfWeek(date = new Date()) {
  const start = startOfWeek(date);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return end;
}

export function isThisWeek(date) {
  if (!date) return false;
  const d = toDate(date);
  const s = startOfWeek();
  const e = endOfWeek();
  return d >= s && d <= e;
}

export function isWithinRange(date, start, end) {
  if (!date) return false;
  const d = toDate(date);
  const s = start ? toDate(start) : null;
  const e = end ? toDate(end) : null;
  if (s && d < s) return false;
  if (e && d > e) return false;
  return true;
}

export function compareByPriority(a, b) {
  const rank = { high: 3, medium: 2, low: 1 };
  return (rank[a] ?? 0) - (rank[b] ?? 0);
}
