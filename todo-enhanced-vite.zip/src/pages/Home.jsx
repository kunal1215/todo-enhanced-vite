import { useMemo, useState } from "react";
import TaskCard from "../components/TaskCard";
import FilterBar from "../components/FilterBar";
import { useTasks } from "../context/TaskContext";
import { compareByPriority, isThisWeek, isToday, isWithinRange } from "../utils/dateUtils";

export default function Home() {
  const { state, dispatch } = useTasks();
  const { tasks, filters } = state;

  const [draft, setDraft] = useState({ title: "", description: "", dueDate: "", priority: "medium" });

  function addTask(e) {
    e.preventDefault();
    if (!draft.title.trim()) return;
    const t = {
      id: crypto.randomUUID(),
      title: draft.title.trim(),
      description: draft.description.trim(),
      dueDate: draft.dueDate || "",
      priority: draft.priority,
      completed: false,
      createdAt: Date.now(),
    };
    dispatch({ type: "ADD_TASK", payload: t });
    setDraft({ title: "", description: "", dueDate: "", priority: "medium" });
  }

  function updateTask(task) {
    dispatch({ type: "UPDATE_TASK", payload: task });
  }

  function filtered(tasks) {
    const q = filters.query.toLowerCase();
    return tasks.filter(t => {
      if (!filters.priorities.has(t.priority)) return false;
      if (filters.datePreset === "today" && !isToday(t.dueDate)) return false;
      if (filters.datePreset === "thisWeek" && !isThisWeek(t.dueDate)) return false;
      if (filters.datePreset === "custom" && !isWithinRange(t.dueDate, filters.startDate, filters.endDate)) return false;
      if (q && !(t.title + " " + t.description).toLowerCase().includes(q)) return false;
      return true;
    }).sort((a, b) => {
      const dir = filters.sortDir === "asc" ? 1 : -1;
      if (filters.sortBy === "priority") return dir * compareByPriority(a.priority, b.priority);
      if (filters.sortBy === "dueDate") return dir * (a.dueDate.localeCompare(b.dueDate));
      return dir * (a.createdAt - b.createdAt);
    });
  }

  const list = useMemo(() => filtered(tasks), [tasks, filters]);

  return (
    <div className="mx-auto max-w-3xl p-4 md:p-8 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl font-bold">Tasks</h1>
        <p className="text-slate-600 text-sm">Manage your day with date filters and priority badges.</p>
      </header>
      <form onSubmit={addTask} className="rounded-2xl border p-4 bg-white grid gap-3 md:grid-cols-4">
        <input className="rounded-xl border px-3 py-2 md:col-span-2" placeholder="Task title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} required />
        <input className="rounded-xl border px-3 py-2 md:col-span-2" placeholder="Description" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
        <input type="date" className="rounded-xl border px-3 py-2" value={draft.dueDate} onChange={(e) => setDraft({ ...draft, dueDate: e.target.value })} />
        <select className="rounded-xl border px-3 py-2" value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })}>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <button className="rounded-xl bg-slate-900 text-white px-4 py-2 hover:opacity-90">Add</button>
      </form>
      <FilterBar />
      {list.length === 0 && <div className="text-center text-slate-500 border rounded-2xl p-8 bg-white">No tasks match your filters.</div>}
      <div className="space-y-3">{list.map(t => (
        <TaskCard key={t.id} task={t} onToggle={(id) => dispatch({ type: "TOGGLE_COMPLETE", payload: id })} onDelete={(id) => dispatch({ type: "DELETE_TASK", payload: id })} onEdit={(task) => updateTask(task)} />
      ))}</div>
    </div>
  );
}
