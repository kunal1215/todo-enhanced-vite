import { createContext, useContext, useEffect, useMemo, useReducer } from "react";

const TaskContext = createContext();

const initialState = {
  tasks: [],
  filters: {
    datePreset: "all",
    startDate: "",
    endDate: "",
    priorities: new Set(["low", "medium", "high"]),
    sortBy: "createdAt",
    sortDir: "asc",
    query: "",
  },
};

function reducer(state, action) {
  switch (action.type) {
    case "LOAD":
      return action.payload ?? state;
    case "ADD_TASK":
      return { ...state, tasks: [action.payload, ...state.tasks] };
    case "UPDATE_TASK":
      return { ...state, tasks: state.tasks.map(t => t.id === action.payload.id ? { ...t, ...action.payload } : t) };
    case "TOGGLE_COMPLETE":
      return { ...state, tasks: state.tasks.map(t => t.id === action.payload ? { ...t, completed: !t.completed } : t) };
    case "DELETE_TASK":
      return { ...state, tasks: state.tasks.filter(t => t.id !== action.payload) };
    case "SET_FILTERS":
      return { ...state, filters: { ...state.filters, ...action.payload } };
    default:
      return state;
  }
}

export function TaskProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const raw = localStorage.getItem("todo.state");
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed?.filters?.priorities) {
          parsed.filters.priorities = new Set(parsed.filters.priorities);
        }
        dispatch({ type: "LOAD", payload: parsed });
      } catch (e) {
        console.error("Failed to parse saved state", e);
      }
    }
  }, []);

  useEffect(() => {
    const toSave = {
      ...state,
      filters: { ...state.filters, priorities: Array.from(state.filters.priorities) },
    };
    localStorage.setItem("todo.state", JSON.stringify(toSave));
  }, [state]);

  const value = useMemo(() => ({ state, dispatch }), [state]);
  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
}

export function useTasks() {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error("useTasks must be used within TaskProvider");
  return ctx;
}
